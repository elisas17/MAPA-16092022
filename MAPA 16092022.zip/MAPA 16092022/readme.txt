Para rodar o arquivo tem que importar o arquivo sql com o nome do banco de dados que est� na pasta import, o nome do banco de dados est� como banco_protocolo,
E a conex�o com o banco de dados est�o vazia

E a classe do que faz conex�o com o banco de dados est� em includes o arquivo conexao.php